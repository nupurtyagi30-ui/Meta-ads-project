import serverless from "../vendor/serverless-http/serverless-http.js";
import app from "./app";

export const handler = serverless(app);
